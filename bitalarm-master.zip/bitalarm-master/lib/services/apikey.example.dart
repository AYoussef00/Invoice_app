/*
This wont be necessary once i get the firebase cloudfunction up
to wrap the api calls, but I haven't done that yet, so here we are.
*/

const COIN_MARKETCAP_APIKEY = "COINMARKETCAP_APIKEY_HERE";
const COIN_API_APIKEY = "COIN_API_APIKEY_HERE";
const INFURA_SECRET = "INFURA_SECRET_HERE";
const ETHPLORER_APIKEY = 'freekey';
