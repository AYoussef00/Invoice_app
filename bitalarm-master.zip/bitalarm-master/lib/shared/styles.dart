import 'package:flutter/material.dart';

const COLOR_HEADLINE = const Color(0x252525);

const COLOR_SOFT_RED = const Color.fromRGBO(255, 104, 104, 1);
const COLOR_SOFT_BLUE = const Color.fromRGBO(155, 99, 239, 1);
