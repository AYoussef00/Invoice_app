class OrderBookModel {
  final List<dynamic> asks;
  final List<dynamic> bids;

  OrderBookModel({this.asks = const [], this.bids = const []});
}
